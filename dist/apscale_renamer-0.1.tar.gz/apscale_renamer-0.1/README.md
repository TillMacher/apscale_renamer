# apscale_renamer
 File renamer for .fastq.gz files (mainly for Windows users)
